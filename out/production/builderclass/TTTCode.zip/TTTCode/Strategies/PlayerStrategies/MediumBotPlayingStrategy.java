package TTTCode.Strategies.PlayerStrategies;

public class MediumBotPlayingStrategy {
}
