package TTTCode.Models;

public enum GameState {
    IN_PROGRESS,
    ENDED,
    DRAW
}
