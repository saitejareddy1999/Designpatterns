package TTTCode.Models;

public enum PlayerType {
    BOT,
    HUMAN
}
