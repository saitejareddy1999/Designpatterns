package TTTCode.Models;

public enum BotDifficultyLevel {
    EASY,MEDIUM,HARD
}
