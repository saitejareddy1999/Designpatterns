package TTTCode.Models;

public enum CellState {
    EMPTY,
    FILLED,
    BLOCKED
}
